/**
 * 
 */
/**
 * @author JAVA01
 *
 */
module OracleDatabase {
	requires java.sql;
}